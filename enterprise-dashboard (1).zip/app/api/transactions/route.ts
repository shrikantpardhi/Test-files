import { NextResponse } from "next/server"

// Mock transaction data
const transactions = [
  {
    id: "TXN-001",
    user: "John Doe",
    email: "john@example.com",
    amount: 299.99,
    status: "completed",
    date: "2024-01-15",
    type: "payment",
  },
  {
    id: "TXN-002",
    user: "Jane Smith",
    email: "jane@example.com",
    amount: 149.5,
    status: "pending",
    date: "2024-01-14",
    type: "subscription",
  },
  {
    id: "TXN-003",
    user: "Bob Johnson",
    email: "bob@example.com",
    amount: 75.0,
    status: "failed",
    date: "2024-01-13",
    type: "payment",
  },
  {
    id: "TXN-004",
    user: "Alice Brown",
    email: "alice@example.com",
    amount: 199.99,
    status: "completed",
    date: "2024-01-12",
    type: "refund",
  },
  {
    id: "TXN-005",
    user: "Charlie Wilson",
    email: "charlie@example.com",
    amount: 89.99,
    status: "completed",
    date: "2024-01-11",
    type: "subscription",
  },
]

export async function GET(request: Request) {
  const { searchParams } = new URL(request.url)
  const page = Number.parseInt(searchParams.get("page") || "1")
  const limit = Number.parseInt(searchParams.get("limit") || "10")
  const search = searchParams.get("search") || ""
  const status = searchParams.get("status")

  // Filter transactions
  let filteredTransactions = transactions

  if (search) {
    filteredTransactions = filteredTransactions.filter(
      (transaction) =>
        transaction.user.toLowerCase().includes(search.toLowerCase()) ||
        transaction.email.toLowerCase().includes(search.toLowerCase()) ||
        transaction.id.toLowerCase().includes(search.toLowerCase()),
    )
  }

  if (status) {
    filteredTransactions = filteredTransactions.filter((transaction) => transaction.status === status)
  }

  // Paginate
  const startIndex = (page - 1) * limit
  const endIndex = startIndex + limit
  const paginatedTransactions = filteredTransactions.slice(startIndex, endIndex)

  return NextResponse.json({
    data: paginatedTransactions,
    pagination: {
      page,
      limit,
      total: filteredTransactions.length,
      totalPages: Math.ceil(filteredTransactions.length / limit),
    },
  })
}
