"use client"

import type React from "react"
import { useEffect, useCallback, useMemo } from "react"
import { useAppSelector, useAppDispatch } from "@/lib/hooks"
import { setTheme, setSystemPreference, setInitialized } from "@/lib/features/theme/theme-slice"

export function ThemeProvider({ children }: { children: React.ReactNode }) {
  const dispatch = useAppDispatch()
  const { mode, isInitialized } = useAppSelector((state) => state.theme)

  const applyTheme = useCallback((theme: "light" | "dark") => {
    const root = document.documentElement
    if (theme === "dark") {
      root.classList.add("dark")
    } else {
      root.classList.remove("dark")
    }
  }, [])

  const detectSystemPreference = useCallback(() => {
    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)")
    const systemTheme = mediaQuery.matches ? "dark" : "light"
    dispatch(setSystemPreference(systemTheme))
    return systemTheme
  }, [dispatch])

  useEffect(() => {
    if (isInitialized) return

    const savedTheme = localStorage.getItem("theme") as "light" | "dark" | null
    const systemTheme = detectSystemPreference()
    const initialTheme = savedTheme || systemTheme

    dispatch(setTheme(initialTheme))
    dispatch(setInitialized(true))
    applyTheme(initialTheme)

    const mediaQuery = window.matchMedia("(prefers-color-scheme: dark)")
    const handleSystemThemeChange = (e: MediaQueryListEvent) => {
      const newSystemTheme = e.matches ? "dark" : "light"
      dispatch(setSystemPreference(newSystemTheme))

      // Only update theme if no user preference is saved
      if (!localStorage.getItem("theme")) {
        dispatch(setTheme(newSystemTheme))
      }
    }

    mediaQuery.addEventListener("change", handleSystemThemeChange)
    return () => mediaQuery.removeEventListener("change", handleSystemThemeChange)
  }, [dispatch, applyTheme, detectSystemPreference, isInitialized])

  useEffect(() => {
    if (!isInitialized) return

    const timeoutId = requestAnimationFrame(() => {
      localStorage.setItem("theme", mode)
      applyTheme(mode)
    })

    return () => cancelAnimationFrame(timeoutId)
  }, [mode, applyTheme, isInitialized])

  const memoizedChildren = useMemo(() => children, [children])

  return <>{memoizedChildren}</>
}
