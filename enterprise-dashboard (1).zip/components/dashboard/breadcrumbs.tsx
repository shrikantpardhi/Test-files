"use client"

import { ChevronRight, Home } from "lucide-react"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface BreadcrumbItem {
  label: string
  href?: string
  current?: boolean
}

interface BreadcrumbsProps {
  items?: BreadcrumbItem[]
  className?: string
}

export function Breadcrumbs({ items, className }: BreadcrumbsProps) {
  // Default breadcrumb items for demo
  const defaultItems: BreadcrumbItem[] = [
    { label: "Dashboard", href: "/dashboard" },
    { label: "Overview", current: true },
  ]

  const breadcrumbItems = items || defaultItems

  return (
    <nav aria-label="Breadcrumb" className={cn("flex items-center space-x-1 text-sm text-muted-foreground", className)}>
      <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-foreground">
        <Home className="h-4 w-4" />
        <span className="sr-only">Home</span>
      </Button>

      {breadcrumbItems.map((item, index) => (
        <div key={index} className="flex items-center space-x-1">
          <ChevronRight className="h-4 w-4 text-muted-foreground/50" />

          {item.current ? (
            <span className="font-medium text-foreground px-2 py-1">{item.label}</span>
          ) : (
            <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-foreground">
              {item.label}
            </Button>
          )}
        </div>
      ))}
    </nav>
  )
}

// Hook for managing breadcrumb state
export function useBreadcrumbs() {
  const setBreadcrumbs = (items: BreadcrumbItem[]) => {
    // In a real app, this would update global state or context
    console.log("Setting breadcrumbs:", items)
  }

  return { setBreadcrumbs }
}
