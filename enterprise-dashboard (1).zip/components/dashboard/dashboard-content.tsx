"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Breadcrumbs } from "./breadcrumbs"
import { DataTable } from "./data-table"
import { StatsCards } from "./stats-cards"

export function DashboardContent() {
  return (
    <div className="space-y-6">
      <Breadcrumbs />

      <div className="space-y-4">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-balance">Dashboard Overview</h1>
          <p className="text-muted-foreground text-pretty">
            Welcome to your enterprise dashboard. Monitor key metrics and manage your data efficiently.
          </p>
        </div>

        <StatsCards />

        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest transactions and system updates</CardDescription>
          </CardHeader>
          <CardContent>
            <DataTable />
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
