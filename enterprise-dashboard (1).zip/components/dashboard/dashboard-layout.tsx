"use client"

import type React from "react"
import { DashboardHeader } from "./dashboard-header"
import { DashboardSidebar } from "./dashboard-sidebar"
import { cn } from "@/lib/utils"
import { useAppDispatch, useAppSelector } from "@/lib/hooks"
import { toggleSidebar } from "@/lib/features/dashboard/dashboard-slice"

interface DashboardLayoutProps {
  children: React.ReactNode
}

export function DashboardLayout({ children }: DashboardLayoutProps) {
  const dispatch = useAppDispatch()
  const { sidebarCollapsed } = useAppSelector((state) => state.dashboard)

  const handleToggleSidebar = () => {
    dispatch(toggleSidebar())
  }

  return (
    <div className="min-h-screen bg-background">
      <DashboardHeader onToggleSidebar={handleToggleSidebar} sidebarCollapsed={sidebarCollapsed} />
      <div className="flex">
        <DashboardSidebar collapsed={sidebarCollapsed} />
        <main className={cn("flex-1 transition-all duration-300 ease-in-out", sidebarCollapsed ? "ml-16" : "ml-64")}>
          <div className="p-6">{children}</div>
        </main>
      </div>
    </div>
  )
}
