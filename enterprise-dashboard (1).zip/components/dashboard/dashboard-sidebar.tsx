"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible"
import { cn } from "@/lib/utils"
import {
  Home,
  BarChart3,
  Users,
  Settings,
  FileText,
  ShoppingCart,
  CreditCard,
  Package,
  ChevronDown,
  ChevronRight,
  Database,
  Shield,
  Bell,
  HelpCircle,
} from "lucide-react"

interface SidebarProps {
  collapsed: boolean
}

interface MenuItem {
  title: string
  icon: React.ComponentType<{ className?: string }>
  href?: string
  children?: MenuItem[]
}

const menuItems: MenuItem[] = [
  {
    title: "Dashboard",
    icon: Home,
    href: "/dashboard",
  },
  {
    title: "Analytics",
    icon: BarChart3,
    children: [
      { title: "Overview", icon: BarChart3, href: "/analytics/overview" },
      { title: "Reports", icon: FileText, href: "/analytics/reports" },
      { title: "Insights", icon: Database, href: "/analytics/insights" },
    ],
  },
  {
    title: "Users",
    icon: Users,
    children: [
      { title: "All Users", icon: Users, href: "/users" },
      { title: "Roles", icon: Shield, href: "/users/roles" },
      { title: "Permissions", icon: Shield, href: "/users/permissions" },
    ],
  },
  {
    title: "E-commerce",
    icon: ShoppingCart,
    children: [
      { title: "Products", icon: Package, href: "/ecommerce/products" },
      { title: "Orders", icon: ShoppingCart, href: "/ecommerce/orders" },
      { title: "Payments", icon: CreditCard, href: "/ecommerce/payments" },
    ],
  },
  {
    title: "Settings",
    icon: Settings,
    children: [
      { title: "General", icon: Settings, href: "/settings/general" },
      { title: "Notifications", icon: Bell, href: "/settings/notifications" },
      { title: "Security", icon: Shield, href: "/settings/security" },
    ],
  },
  {
    title: "Help",
    icon: HelpCircle,
    href: "/help",
  },
]

interface SidebarItemProps {
  item: MenuItem
  collapsed: boolean
  level?: number
}

function SidebarItem({ item, collapsed, level = 0 }: SidebarItemProps) {
  const [isOpen, setIsOpen] = useState(false)
  const hasChildren = item.children && item.children.length > 0
  const Icon = item.icon

  if (hasChildren) {
    return (
      <Collapsible open={isOpen} onOpenChange={setIsOpen}>
        <CollapsibleTrigger asChild>
          <Button
            variant="ghost"
            className={cn(
              "w-full justify-start gap-3 h-10 px-3 sidebar-transition",
              level > 0 && "ml-4",
              collapsed && "px-2 justify-center",
            )}
          >
            <Icon className="h-4 w-4 shrink-0" />
            {!collapsed && (
              <>
                <span className="truncate">{item.title}</span>
                <div className="ml-auto">
                  {isOpen ? (
                    <ChevronDown className="h-4 w-4 sidebar-transition" />
                  ) : (
                    <ChevronRight className="h-4 w-4 sidebar-transition" />
                  )}
                </div>
              </>
            )}
          </Button>
        </CollapsibleTrigger>
        {!collapsed && (
          <CollapsibleContent className="space-y-1 slide-in-left">
            {item.children?.map((child, index) => (
              <SidebarItem key={index} item={child} collapsed={collapsed} level={level + 1} />
            ))}
          </CollapsibleContent>
        )}
      </Collapsible>
    )
  }

  return (
    <Button
      variant="ghost"
      className={cn(
        "w-full justify-start gap-3 h-10 px-3 sidebar-transition",
        level > 0 && "ml-4",
        collapsed && "px-2 justify-center",
      )}
    >
      <Icon className="h-4 w-4 shrink-0" />
      {!collapsed && <span className="truncate">{item.title}</span>}
    </Button>
  )
}

export function DashboardSidebar({ collapsed }: SidebarProps) {
  return (
    <aside
      className={cn(
        "fixed left-0 top-16 z-40 h-[calc(100vh-4rem)] border-r border-gray-200 dark:border-gray-800 bg-sidebar sidebar-transition slide-in-left",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-full flex-col">
        <div className="flex-1 overflow-y-auto py-4">
          <nav className="space-y-1 px-2">
            {menuItems.map((item, index) => (
              <SidebarItem key={index} item={item} collapsed={collapsed} />
            ))}
          </nav>
        </div>

        {/* Footer */}
        <div className="border-t border-sidebar-border p-4">
          {!collapsed ? (
            <div className="text-xs text-muted-foreground text-center fade-in">Enterprise Dashboard v1.0</div>
          ) : (
            <div className="flex justify-center">
              <div className="h-2 w-2 rounded-full bg-primary fade-in"></div>
            </div>
          )}
        </div>
      </div>
    </aside>
  )
}
