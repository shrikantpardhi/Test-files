import { createSlice, type PayloadAction } from "@reduxjs/toolkit"

interface DashboardState {
  sidebarCollapsed: boolean
  currentPage: string
  notifications: number
}

const initialState: DashboardState = {
  sidebarCollapsed: false,
  currentPage: "dashboard",
  notifications: 3,
}

export const dashboardSlice = createSlice({
  name: "dashboard",
  initialState,
  reducers: {
    toggleSidebar: (state) => {
      state.sidebarCollapsed = !state.sidebarCollapsed
    },
    setCurrentPage: (state, action: PayloadAction<string>) => {
      state.currentPage = action.payload
    },
    updateNotifications: (state, action: PayloadAction<number>) => {
      state.notifications = action.payload
    },
  },
})

export const { toggleSidebar, setCurrentPage, updateNotifications } = dashboardSlice.actions
