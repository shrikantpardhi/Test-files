import { createSlice, type PayloadAction } from "@reduxjs/toolkit"

interface ThemeState {
  mode: "light" | "dark"
  systemPreference: "light" | "dark"
  isInitialized: boolean
}

const initialState: ThemeState = {
  mode: "light",
  systemPreference: "light",
  isInitialized: false,
}

export const themeSlice = createSlice({
  name: "theme",
  initialState,
  reducers: {
    toggleTheme: (state) => {
      state.mode = state.mode === "light" ? "dark" : "light"
    },
    setTheme: (state, action: PayloadAction<"light" | "dark">) => {
      state.mode = action.payload
    },
    setSystemPreference: (state, action: PayloadAction<"light" | "dark">) => {
      state.systemPreference = action.payload
    },
    setInitialized: (state, action: PayloadAction<boolean>) => {
      state.isInitialized = action.payload
    },
  },
})

export const { toggleTheme, setTheme, setSystemPreference, setInitialized } = themeSlice.actions
