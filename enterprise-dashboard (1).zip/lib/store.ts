import { configureStore } from "@reduxjs/toolkit"
import { dashboardSlice } from "./features/dashboard/dashboard-slice"
import { themeSlice } from "./features/theme/theme-slice"

export const makeStore = () => {
  return configureStore({
    reducer: {
      dashboard: dashboardSlice.reducer,
      theme: themeSlice.reducer,
    },
  })
}

export type AppStore = ReturnType<typeof makeStore>
export type RootState = ReturnType<AppStore["getState"]>
export type AppDispatch = AppStore["dispatch"]
